# Jak zbudować APK z telefonu przez GitHub

1. Zaloguj się na https://github.com w Chrome.
2. Utwórz nowe repozytorium (New repository), np. `retro-racing-android`.
   Ustaw je jako **Public** lub **Private**.
3. Wgraj do repozytorium całą zawartość tego folderu ZIP (nie sam folder nadrzędny).
   Najłatwiej: rozpakuj ZIP na telefonie, a następnie w GitHub wybierz
   **Add file → Upload files** i dodaj pliki oraz foldery.
4. Otwórz kartę **Actions** w repozytorium i zaakceptuj włączenie workflow,
   jeśli GitHub o to poprosi.
5. Wybierz workflow **Build Android APK**, kliknij **Run workflow**.
6. Po zakończeniu zielonego zadania otwórz jego stronę, przewiń do
   **Artifacts** i pobierz `RetroRacing-Android-APK`.
7. Rozpakuj pobrane archiwum ZIP. W środku będzie `RetroRacing.apk`.
   Otwórz APK i zezwól Androidowi na instalację z tej przeglądarki/menedżera plików.

Jeśli kompilacja zakończy się błędem, otwórz log zadania w GitHub Actions
i prześlij mi treść błędu — pomogę go poprawić.

Uwaga: ten ZIP zawiera projekt i konfigurację automatycznej kompilacji,
nie gotowy APK. GitHub Actions ma dopiero zbudować APK. Workflow używa
obrazu CI Godot 4.3 i eksportu Android ARM64.
