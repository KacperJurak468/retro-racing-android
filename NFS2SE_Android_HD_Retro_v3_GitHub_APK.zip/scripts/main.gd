extends Node3D

# Fan-made retro racing prototype. Original Need for Speed assets are not included.

const CARS := [
    {"name":"McLaren F1","color":Color("c8cbd0"),"top":325.0,"handling":1.00,"accel":1.0},
    {"name":"Ferrari F50","color":Color("c72d27"),"top":310.0,"handling":1.10,"accel":1.08},
    {"name":"Jaguar XJ220","color":Color("1686b8"),"top":315.0,"handling":0.94,"accel":1.04},
    {"name":"Ford GT90","color":Color("e7e8e9"),"top":330.0,"handling":0.90,"accel":0.98},
    {"name":"Lotus Esprit V8","color":Color("d5b92b"),"top":285.0,"handling":1.20,"accel":1.12},
    {"name":"Italdesign Cala","color":Color("5ba36d"),"top":290.0,"handling":1.08,"accel":1.06}
]
const TRACKS := [
    {"name":"Pacific Spirit","sky":Color("68b4d6"),"ground":Color("397a58"),"tree":Color("246044")},
    {"name":"Mystic Peaks","sky":Color("879ab4"),"ground":Color("596d50"),"tree":Color("344d3b")},
    {"name":"Outback","sky":Color("e4a05e"),"ground":Color("a85f38"),"tree":Color("8b6b38")},
    {"name":"Mediterranean","sky":Color("e68d72"),"ground":Color("a69b5a"),"tree":Color("536b3d")},
    {"name":"Northern Lights","sky":Color("536f89"),"ground":Color("315940"),"tree":Color("21442f")}
]
const RACE_LENGTH_M := 5000.0

var selected_car := 0
var selected_track := 0
var speed := 0.0
var distance_m := 0.0
var race_seconds := 0.0
var nitro := 100.0
var player_x := 0.0
var racing := false
var paused := false
var countdown := 3.0
var menu_layer: CanvasLayer
var camera: Camera3D
var player_car: Node3D
var world_env: WorldEnvironment
var road_root: Node3D
var scenery_root: Node3D
var road_dashes: Array[Node3D] = []
var scenery: Array[Node3D] = []
var opponents: Array[Dictionary] = []
var hud_speed: Label
var hud_distance: Label
var hud_nitro: Label
var hud_position: Label
var hud_countdown: Label
var race_message: Label
var engine_player: AudioStreamPlayer
var engine_playback: AudioStreamGeneratorPlayback
var engine_phase := 0.0
var touch_actions := {"gas":false,"brake":false,"left":false,"right":false,"nitro":false}

func _ready() -> void:
    randomize()
    _create_world()
    _show_main_menu()

func _material(color: Color, metallic := 0.0, roughness := 0.65) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.metallic = metallic
    m.roughness = roughness
    return m

func _box(parent: Node3D, size: Vector3, pos: Vector3, color: Color, metallic := 0.0) -> MeshInstance3D:
    var node := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = size
    node.mesh = mesh
    node.position = pos
    node.material_override = _material(color, metallic)
    parent.add_child(node)
    return node

func _create_world() -> void:
    world_env = WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color("263f5c")
    sky_mat.sky_horizon_color = Color("a9bdc9")
    sky_mat.ground_bottom_color = Color("1d292d")
    sky_mat.ground_horizon_color = Color("819294")
    sky.sky_material = sky_mat
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("b4c3ce")
    env.ambient_light_energy = 0.75
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -25, 0)
    sun.light_energy = 1.15
    add_child(sun)

    camera = Camera3D.new()
    camera.position = Vector3(0, 5.0, 10.5)
    camera.rotation_degrees = Vector3(-16, 0, 0)
    camera.current = true
    add_child(camera)

    road_root = Node3D.new()
    add_child(road_root)
    scenery_root = Node3D.new()
    add_child(scenery_root)
    _build_road()
    _build_scenery()
    player_car = _make_car_model(CARS[selected_car].color, true)
    player_car.position = Vector3(0, 0.1, 4.0)
    add_child(player_car)
    _setup_engine_audio()

func _build_road() -> void:
    var ground := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(180, 520)
    ground.mesh = plane
    ground.position = Vector3(0, -0.16, -205)
    ground.material_override = _material(TRACKS[selected_track].ground)
    road_root.add_child(ground)
    _box(road_root, Vector3(12.5, 0.12, 500), Vector3(0, -0.02, -205), Color("343a3f"))
    _box(road_root, Vector3(0.18, 0.035, 500), Vector3(-6.12, 0.06, -205), Color("e8e0c8"))
    _box(road_root, Vector3(0.18, 0.035, 500), Vector3(6.12, 0.06, -205), Color("e8e0c8"))
    for i in range(42):
        var dash := _box(road_root, Vector3(0.17, 0.04, 3.1), Vector3(0, 0.07, -i * 11.5), Color("eee8d8"))
        road_dashes.append(dash)

func _build_scenery() -> void:
    for side in [-1, 1]:
        for i in range(25):
            var tree := Node3D.new()
            tree.position = Vector3(side * (10.0 + float(i % 4) * 1.6), 0, -i * 19.0 - 5)
            scenery_root.add_child(tree)
            var trunk := MeshInstance3D.new()
            var trunk_mesh := CylinderMesh.new()
            trunk_mesh.top_radius = 0.15
            trunk_mesh.bottom_radius = 0.23
            trunk_mesh.height = 1.6
            trunk.mesh = trunk_mesh
            trunk.position.y = 0.8
            trunk.material_override = _material(Color("60452e"))
            tree.add_child(trunk)
            var crown := MeshInstance3D.new()
            var crown_mesh := SphereMesh.new()
            crown_mesh.radius = 1.55
            crown_mesh.height = 3.0
            crown.mesh = crown_mesh
            crown.position.y = 2.15
            crown.material_override = _material(TRACKS[selected_track].tree)
            tree.add_child(crown)
            scenery.append(tree)

func _make_car_model(color: Color, player: bool) -> Node3D:
    var car := Node3D.new()
    var body_color := color
    _box(car, Vector3(1.9, 0.56, 3.55), Vector3(0, 0.61, 0), body_color, 0.48)
    _box(car, Vector3(1.48, 0.48, 1.65), Vector3(0, 1.08, 0.12), Color("263e51"), 0.4)
    _box(car, Vector3(1.72, 0.13, 0.65), Vector3(0, 0.83, -1.45), body_color, 0.4)
    _box(car, Vector3(1.7, 0.12, 0.35), Vector3(0, 0.9, 1.55), body_color, 0.4)
    _box(car, Vector3(0.36, 0.12, 0.13), Vector3(-0.58, 0.64, -1.79), Color("fff1c2"), 0.1)
    _box(car, Vector3(0.36, 0.12, 0.13), Vector3(0.58, 0.64, -1.79), Color("fff1c2"), 0.1)
    _box(car, Vector3(0.4, 0.12, 0.13), Vector3(-0.58, 0.64, 1.79), Color("a91e18"))
    _box(car, Vector3(0.4, 0.12, 0.13), Vector3(0.58, 0.64, 1.79), Color("a91e18"))
    for x in [-0.99, 0.99]:
        for z in [-1.1, 1.1]:
            var wheel := MeshInstance3D.new()
            var wm := CylinderMesh.new()
            wm.top_radius = 0.34
            wm.bottom_radius = 0.34
            wm.height = 0.2
            wheel.mesh = wm
            wheel.rotation_degrees.z = 90
            wheel.position = Vector3(x, 0.35, z)
            wheel.material_override = _material(Color("101316"))
            car.add_child(wheel)
            var hub := MeshInstance3D.new()
            var hm := CylinderMesh.new()
            hm.top_radius = 0.14
            hm.bottom_radius = 0.14
            hm.height = 0.215
            hub.mesh = hm
            hub.rotation_degrees.z = 90
            hub.position = Vector3(x * 1.01, 0.35, z)
            hub.material_override = _material(Color("aab2b8"), 0.7)
            car.add_child(hub)
    return car

func _setup_engine_audio() -> void:
    engine_player = AudioStreamPlayer.new()
    var stream := AudioStreamGenerator.new()
    stream.mix_rate = 22050
    stream.buffer_length = 0.12
    engine_player.stream = stream
    engine_player.volume_db = -13
    add_child(engine_player)
    engine_player.play()
    engine_playback = engine_player.get_stream_playback()

func _pump_engine_audio() -> void:
    if engine_playback == null:
        return
    var frames := engine_playback.get_frames_available()
    var freq := 45.0 + speed * 0.72
    for i in range(frames):
        engine_phase += TAU * freq / 22050.0
        var sample := sin(engine_phase) * (0.035 + speed / 9000.0)
        sample += sin(engine_phase * 2.03) * 0.012
        engine_playback.push_frame(Vector2(sample, sample))

func _clear_menu() -> void:
    if is_instance_valid(menu_layer):
        menu_layer.queue_free()
    menu_layer = CanvasLayer.new()
    add_child(menu_layer)

func _panel(layer: CanvasLayer, size: Vector2) -> VBoxContainer:
    var panel := PanelContainer.new()
    panel.anchor_left = 0.5
    panel.anchor_right = 0.5
    panel.anchor_top = 0.5
    panel.anchor_bottom = 0.5
    panel.offset_left = -size.x / 2
    panel.offset_right = size.x / 2
    panel.offset_top = -size.y / 2
    panel.offset_bottom = size.y / 2
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.025, 0.055, 0.09, 0.96)
    style.border_color = Color("91a5b6")
    style.set_border_width_all(2)
    style.set_corner_radius_all(5)
    style.content_margin_left = 22
    style.content_margin_right = 22
    style.content_margin_top = 18
    style.content_margin_bottom = 18
    panel.add_theme_stylebox_override("panel", style)
    layer.add_child(panel)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 9)
    box.alignment = BoxContainer.ALIGNMENT_CENTER
    panel.add_child(box)
    return box

func _label(parent: Control, text: String, size := 20, color := Color.WHITE) -> Label:
    var label := Label.new()
    label.text = text
    label.add_theme_font_size_override("font_size", size)
    label.add_theme_color_override("font_color", color)
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    parent.add_child(label)
    return label

func _button(parent: Control, text: String, action: Callable, min_size := Vector2(250, 45)) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = min_size
    b.add_theme_font_size_override("font_size", 18)
    b.pressed.connect(action)
    parent.add_child(b)
    return b

func _show_main_menu() -> void:
    racing = false
    _clear_menu()
    var p := _panel(menu_layer, Vector2(550, 525))
    _label(p, "NEED FOR SPEED II", 43, Color("f0f3f6"))
    _label(p, "SPECIAL EDITION  •  ANDROID HD RETRO", 14, Color("ffb85b"))
    _label(p, "ROAD TO VICTORY", 25, Color("d8e3ec"))
    _button(p, "START RACE", _start_race)
    _button(p, "CAR SELECT", _show_cars)
    _button(p, "TRACK SELECT", _show_tracks)
    _button(p, "OPTIONS", _show_options)
    _label(p, "FAN-MADE PROTOTYPE • NOT AN OFFICIAL EA PRODUCT", 10, Color("aab9c6"))

func _show_cars() -> void:
    _clear_menu()
    var p := _panel(menu_layer, Vector2(570, 620))
    _label(p, "SELECT YOUR CAR", 29, Color("ffbd62"))
    _label(p, CARS[selected_car].name, 23)
    _label(p, "TOP SPEED  %d KM/H" % int(CARS[selected_car].top), 14, Color("b9c8d5"))
    for i in range(CARS.size()):
        _button(p, CARS[i].name + ("  ✓" if i == selected_car else ""), func(): _choose_car(i), Vector2(310, 39))
    _button(p, "BACK TO MENU", _show_main_menu)

func _choose_car(index: int) -> void:
    selected_car = index
    if is_instance_valid(player_car):
        player_car.queue_free()
    player_car = _make_car_model(CARS[selected_car].color, true)
    player_car.position = Vector3(player_x, 0.1, 4.0)
    add_child(player_car)
    _show_cars()

func _show_tracks() -> void:
    _clear_menu()
    var p := _panel(menu_layer, Vector2(540, 580))
    _label(p, "SELECT YOUR TRACK", 29, Color("ffbd62"))
    for i in range(TRACKS.size()):
        _button(p, TRACKS[i].name + ("  ✓" if i == selected_track else ""), func(): _choose_track(i))
    _button(p, "BACK TO MENU", _show_main_menu)

func _choose_track(index: int) -> void:
    selected_track = index
    _rebuild_track()
    _show_tracks()

func _rebuild_track() -> void:
    for child in road_root.get_children():
        child.queue_free()
    for child in scenery_root.get_children():
        child.queue_free()
    road_dashes.clear()
    scenery.clear()
    _build_road()
    _build_scenery()
    var sky_mat := world_env.environment.sky.sky_material as ProceduralSkyMaterial
    sky_mat.sky_top_color = TRACKS[selected_track].sky
    sky_mat.sky_horizon_color = TRACKS[selected_track].sky.lightened(0.25)

func _show_options() -> void:
    _clear_menu()
    var p := _panel(menu_layer, Vector2(520, 390))
    _label(p, "OPTIONS", 31, Color("ffbd62"))
    _label(p, "DISPLAY: HD RETRO / LANDSCAPE", 17)
    _label(p, "RENDERER: GODOT MOBILE COMPATIBLE", 13, Color("b9c8d5"))
    _label(p, "KEYBOARD: WASD / ARROWS", 16)
    _label(p, "TOUCH: ON-SCREEN HOLD CONTROLS", 16)
    _label(p, "SOUND: PROCEDURAL ENGINE LOOP", 14, Color("b9c8d5"))
    _button(p, "BACK TO MENU", _show_main_menu)

func _hold_button(parent: Control, text: String, action: String, size := Vector2(112, 66)) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = size
    b.add_theme_font_size_override("font_size", 16)
    b.button_down.connect(func(): Input.action_press(action))
    b.button_up.connect(func(): Input.action_release(action))
    parent.add_child(b)
    return b

func _start_race() -> void:
    _clear_menu()
    racing = true
    paused = false
    speed = 0
    distance_m = 0
    race_seconds = 0
    nitro = 100
    player_x = 0
    player_car.position = Vector3(0, 0.1, 4)
    player_car.rotation = Vector3.ZERO
    _spawn_opponents()

    var top := HBoxContainer.new()
    top.anchor_right = 1
    top.offset_left = 16
    top.offset_right = -16
    top.offset_top = 10
    top.offset_bottom = 57
    menu_layer.add_child(top)
    hud_speed = _label(top, "000 KM/H", 24, Color("ffbd62"))
    var spacer := Control.new()
    spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    top.add_child(spacer)
    hud_position = _label(top, "P 4/4", 18)
    hud_distance = _label(top, "0.00 KM", 16)
    _button(top, "Ⅱ", _toggle_pause, Vector2(60, 44))

    var nitro_bar := ProgressBar.new()
    nitro_bar.min_value = 0
    nitro_bar.max_value = 100
    nitro_bar.value = 100
    nitro_bar.show_percentage = false
    nitro_bar.anchor_left = 0
    nitro_bar.anchor_top = 0
    nitro_bar.anchor_right = 0
    nitro_bar.anchor_bottom = 0
    nitro_bar.position = Vector2(18, 66)
    nitro_bar.size = Vector2(190, 17)
    menu_layer.add_child(nitro_bar)
    hud_nitro = _label(menu_layer, "NITRO", 12, Color("b9d8f0"))
    hud_nitro.position = Vector2(215, 63)

    var bottom := HBoxContainer.new()
    bottom.anchor_left = 0
    bottom.anchor_right = 1
    bottom.anchor_top = 1
    bottom.anchor_bottom = 1
    bottom.offset_left = 12
    bottom.offset_right = -12
    bottom.offset_top = -91
    bottom.offset_bottom = -10
    bottom.alignment = BoxContainer.ALIGNMENT_CENTER
    bottom.add_theme_constant_override("separation", 8)
    menu_layer.add_child(bottom)
    _hold_button(bottom, "◀ LEFT", "steer_left")
    _hold_button(bottom, "BRAKE", "brake")
    _hold_button(bottom, "GAS", "accelerate")
    _hold_button(bottom, "NITRO", "nitro")
    _hold_button(bottom, "RIGHT ▶", "steer_right")
    hud_countdown = _label(menu_layer, "3", 46, Color("ffbd62"))
    hud_countdown.position = Vector2(0, 130)
    race_message = _label(menu_layer, TRACKS[selected_track].name.to_upper(), 14, Color("f2d2a0"))
    race_message.position = Vector2(18, 88)
    countdown = 3.0

func _spawn_opponents() -> void:
    for item in opponents:
        (item["node"] as Node3D).queue_free()
    opponents.clear()
    var colors := [Color("d52e26"), Color("e3e5e8"), Color("1a83b5")]
    for i in range(3):
        var rival := _make_car_model(colors[i], false)
        rival.position = Vector3(float(i - 1) * 3.0, 0.1, -22.0 - i * 18.0)
        add_child(rival)
        opponents.append({"node":rival,"base_speed":randf_range(145.0, 235.0),"lane":float(i - 1) * 3.0,"progress":0.0,"phase":randf_range(0, TAU)})

func _toggle_pause() -> void:
    paused = not paused
    if paused:
        var overlay := _panel(menu_layer, Vector2(330, 240))
        _label(overlay, "PAUSED", 30, Color("ffbd62"))
        _button(overlay, "RESUME", _toggle_pause)
        _button(overlay, "QUIT TO MENU", _show_main_menu)

func _update_opponents(delta: float) -> void:
    for i in range(opponents.size()):
        var data: Dictionary = opponents[i]
        var rival: Node3D = data["node"]
        var relative := float(data["base_speed"]) / 3.6 * delta * 0.33
        rival.position.z += (speed * delta * 0.33) - relative
        data["phase"] = float(data["phase"]) + delta * 0.7
        if rival.position.z > 13:
            rival.position.z = -randf_range(80, 145)
            data["lane"] = [-3.3, 0.0, 3.3][randi() % 3]
        var desired_x := float(data["lane"]) + sin(float(data["phase"])) * 0.22
        rival.position.x = lerp(rival.position.x, desired_x, delta * 1.4)
        if rival.position.z > -9 and rival.position.z < 8 and abs(rival.position.x - player_x) < 1.65:
            speed = max(speed - 95.0 * delta, 0)
            rival.position.z -= 2.5
            race_message.text = "COLLISION!"
        opponents[i] = data

func _update_race(delta: float) -> void:
    race_seconds += delta
    if countdown > 0:
        countdown -= delta
        hud_countdown.text = str(max(1, int(ceil(countdown))))
        if countdown <= 0:
            hud_countdown.text = "GO!"
        return
    if countdown > -0.8:
        countdown -= delta
    else:
        hud_countdown.text = ""

    var max_speed: float = float(CARS[selected_car]["top"])
    if Input.is_action_pressed("accelerate"):
        speed = min(speed + 83.0 * float(CARS[selected_car]["accel"]) * delta, max_speed)
    else:
        speed = max(speed - 18.0 * delta, 0)
    if Input.is_action_pressed("brake"):
        speed = max(speed - 145.0 * delta, 0)
    if Input.is_action_pressed("nitro") and nitro > 0:
        speed = min(speed + 120.0 * delta, max_speed + 45.0)
        nitro = max(nitro - 25.0 * delta, 0)

    var steer := 0.0
    if Input.is_action_pressed("steer_left"):
        steer -= 1
    if Input.is_action_pressed("steer_right"):
        steer += 1
    player_x = clamp(player_x + steer * 5.2 * float(CARS[selected_car]["handling"]) * delta, -4.9, 4.9)
    player_car.position.x = player_x
    player_car.rotation.z = lerp(player_car.rotation.z, -steer * 0.14, delta * 5)
    camera.position.x = lerp(camera.position.x, player_x * 0.22, delta * 2)

    var travel := speed * delta * 0.33
    distance_m += speed * delta / 3.6
    for dash in road_dashes:
        dash.position.z += travel
        if dash.position.z > 12:
            dash.position.z -= 42.0 * 11.5
    for tree in scenery:
        tree.position.z += travel
        if tree.position.z > 15:
            tree.position.z -= 25.0 * 19.0
    _update_opponents(delta)
    _update_hud()
    if distance_m >= RACE_LENGTH_M:
        _finish_race()

func _update_hud() -> void:
    hud_speed.text = "%03d KM/H" % int(speed)
    hud_distance.text = "%.2f / 5.00 KM" % (distance_m / 1000.0)
    hud_nitro.text = "NITRO %d%%" % int(nitro)
    var ahead := 0
    for data in opponents:
        var rival: Node3D = data["node"]
        if rival.position.z > 4:
            ahead += 1
    hud_position.text = "P %d/4" % (ahead + 1)

func _finish_race() -> void:
    racing = false
    speed = 0
    var p := _panel(menu_layer, Vector2(420, 300))
    _label(p, "FINISH!", 42, Color("ffbd62"))
    _label(p, "TIME  %.1f SEC" % race_seconds, 22)
    _label(p, "DISTANCE  5.00 KM", 16)
    _button(p, "RACE AGAIN", _start_race)
    _button(p, "MAIN MENU", _show_main_menu)

func _process(delta: float) -> void:
    if racing and not paused:
        _update_race(delta)
    _pump_engine_audio()

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch and racing and not paused:
        var width := get_viewport().get_visible_rect().size.x
        if event.pressed:
            if event.position.x < width * 0.22:
                Input.action_press("steer_left")
            elif event.position.x > width * 0.78:
                Input.action_press("steer_right")
        else:
            Input.action_release("steer_left")
            Input.action_release("steer_right")
