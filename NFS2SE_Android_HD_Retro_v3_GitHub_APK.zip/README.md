# NFS II SE – Android HD Retro v3 (fan-made prototype)

This is an editable Godot 4 project source. It is **not** an official EA product or a recreation containing original game assets. No original Need for Speed models, logos, textures, music or sounds are included.

## Version 3 additions
- Procedural 3D sports-car placeholder models with cabin, lights, wheels and hubs
- Three rival cars with simple relative-speed movement and lane changes
- Basic collision slowdown
- Countdown, finish screen, position indicator and nitro meter
- Hold-to-use on-screen controls for gas, brake, steering and nitro
- Procedurally generated engine loop using Godot AudioStreamGenerator
- Five track palettes and six selectable car profiles

## Build an Android APK
This ZIP is source code, not an APK.
1. Install Godot 4.3 or newer on a computer.
2. Install the matching Godot export templates.
3. Install Android SDK command-line tools, platform-tools, build-tools and a compatible JDK.
4. Configure Android SDK and JDK paths in Godot Editor Settings > Export > Android.
5. Open `project.godot`, choose Project > Export, add an Android preset.
6. Set a unique package name, e.g. `com.example.nfs2retro`.
7. Export a debug APK for testing. Configure a release keystore before publishing.
8. Transfer the APK to your phone and install it (allow installation from your file manager if Android asks).

## Known limitations
- Early prototype, not a finished commercial game.
- Cars are procedural placeholder geometry, not detailed licensed vehicle models.
- Rival logic is basic arcade movement, not advanced racing AI.
- Collision is a simple proximity slowdown, not full physics.
- Track is a looping road prototype, not a complete modeled circuit.
- The procedural engine tone is a placeholder, not original game audio.
- Test on an actual Android device and tune touch layout/performance before release.
