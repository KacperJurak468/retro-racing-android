Engine audio is synthesized at runtime with AudioStreamGenerator in scripts/main.gd. No copyrighted audio is bundled.
